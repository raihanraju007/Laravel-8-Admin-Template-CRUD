<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get(
    'category/add-category',
    [CategoryController::class,'addCategory']
    )->name('add-category');

Route::post(
    'category/new-category',
    [CategoryController::class,'newCategory']
    )->name('new-category');


Route::get(
    '/category/manage-category',
    [CategoryController::class, 'manageCategory']
    )->name('manage-category');

Route::get(
    '/category/edit-category/{id}',
    [CategoryController::class, 'editCategory']
    )->name('edit-category');

Route::post(
    '/category/update-category',
    [CategoryController::class, 'updateCategory']
    )->name('update-category');

Route::post(
    '/category/delete-category',
    [CategoryController::class, 'deleteCategory']
    )->name('delete-category');
