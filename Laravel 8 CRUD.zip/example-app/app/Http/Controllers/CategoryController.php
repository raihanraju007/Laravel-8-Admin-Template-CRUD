<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use DB;

class CategoryController extends Controller
{
    public function addCategory(){
        return view('admin.category.add-category');
    }

    public  function newCategory(Request $request){

//        All Function in Category Model function


            //Way 1
//        DB::table('categories')->insert([
//            'category_name'         => $request->category_name,
//            'category_description'  => $request->category_description,
//            'publication_status'    => $request->publication_status,
//        ]);
//
//        return 'Success';

        // Way 2

//        $category =new Category();
//        $category->category_name =$request->category_name;
//        $category->category_description=$request->category_description;
//        $category->publication_status=$request->publication_status;
//        $category->save();
//
//        return 'Success';


//Way 3
        //Category::create($request->all());
//        return redirect('/category/add-category')->with('message','Category Information Save successfully');

//        Way 1 when use this way funcation must be static
        Category::saveCategoryInfo($request);

//     Way 2 None static function
//        $category =new Category();
//        $category->saveCategoryInfo($request);
return redirect('/category/add-category')->with('message','Category Information Save successfully');

    }

    public function manageCategory(){

        return view('admin.category.manage-category',[

            'categories' => Category::all()
        ]);

    }

    public function editCategory($id){
        return view('admin.category.edit-category',[
            'category' => Category::find($id)
        ]);
    }

    public function updateCategory(Request $request){

//        Copy to model class for batter coding practise
//        $category=Category::find($request->id);
//        $category->category_name =$request->category_name;
//        $category->category_description=$request->category_description;
//        $category->publication_status =$request->publication_status;
//        $category->save();

        Category::updateCategoryInfo($request);

        return redirect('/category/manage-category')->with('message','Category Information Update successfully');
    }

    public function deleteCategory(Request $request){
        $category =Category::find($request->id);
        $category->delete();
        return redirect('/category/manage-category')->with('message','Category Information delete successfully');
    }
}
