<?php
 ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/category/manage-category.blade.php ENDPATH**/ ?>
