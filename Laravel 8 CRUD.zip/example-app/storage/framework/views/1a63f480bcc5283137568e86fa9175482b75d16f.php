<?php $__env->startSection('title'); ?>
    Manage Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
        </div>
        <div class="card-body">
            <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>SL</th>
                        <th>Category Name</th>
                        <th>Category Description</th>
                        <th>Publication Status</th>
                        <th>Action</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <td><?php echo e($category->category_description); ?></td>
                        <td><?php echo e($category->publication_status ==1 ? 'Published' : 'Unpublished'); ?></td>
                        <td>
                            <a href="<?php echo e(route('edit-category',['id' =>$category->id])); ?>">Edit</a>
                            <a href="#" id="<?php echo e($category->id); ?>" class="delete-btn">Delete</a>
                            <form id="deleteCategoryForm<?php echo e($category->id); ?>" action="<?php echo e(route('delete-category')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($category->id); ?>" name="id">
                            </form>
                        </td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/category/manage-category.blade.php ENDPATH**/ ?>